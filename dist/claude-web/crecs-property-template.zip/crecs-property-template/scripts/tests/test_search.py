"""The search page's layout document: the checks agree with the plugin, the commands edit
it the way they say, and a change the plugin would refuse is never written.

The conformance cases read tests/fixtures/search-vectors.json, which the plugin's
tools/search-layout/build-search-reference.php generates by running the plugin's own
checks on each sample. If this file and the plugin disagree on a single word, the skill
would tell a person something different from what the preview then does.
"""

import contextlib
import copy
import io
import json
import os
import shutil
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

import crecs_preview
from crecs import search_cli
from crecs.search_layout import REFERENCE, Vocabulary, blocking, find, normalise
from crecs_preview import canonical_hash

HERE = os.path.dirname(os.path.abspath(__file__))
VECTORS = os.path.join(HERE, "fixtures", "search-vectors.json")

CODES = {"E-SL-SHAPE", "E-SL-ROOT", "E-SL-NODE", "E-SL-ID", "E-SL-BLOCK", "E-SL-ELTYPE",
         "E-SL-CHILDREN", "E-SL-REQUIRED", "E-SL-ONCE", "E-SL-WITHIN", "E-SL-NOT-WITHIN",
         "E-SL-SETTING", "E-SL-VALUE", "E-SL-STUCK", "E-SL-LIMIT"}

# Ids in the built-in layout, as the reference records it.
PAGE, WRAPPER, MAP, FILTERS = "5e2a0001", "5e2a0002", "5e2a0004", "5e2a0005"
KEYWORD, PROPERTY_TYPE, SIZE, RATE, CLEAR = "5e2a0006", "5e2a0008", "5e2a0009", "5e2a000a", "5e2a000c"
LISTINGS, SORT, RESULTS = "5e2a000d", "5e2a000f", "5e2a0011"


def vectors():
    with open(VECTORS, encoding="utf-8") as fh:
        return json.load(fh)


class AgreesWithThePlugin(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.vocab = Vocabulary.load()
        cls.vectors = vectors()

    def test_every_value_gets_the_plugins_verdict(self):
        for sample in self.vectors["values"]:
            spec = self.vocab.controls(sample["block"])[sample["control"]]
            with self.subTest(control=sample["control"], value=sample["json"]):
                self.assertEqual(sample["problem"], self.vocab.problem(spec, json.loads(sample["json"])))

    def test_every_document_gets_the_plugins_findings(self):
        for sample in self.vectors["documents"]:
            with self.subTest(document=sample["name"]):
                self.assertEqual(sample["findings"], self.vocab.check(sample["document"]))

    def test_a_different_verdict_would_be_seen(self):
        # The cases above compare whole strings and whole finding lists; prove a single
        # changed word is enough to fail them.
        sample = copy.deepcopy(self.vectors["documents"][1])
        self.assertTrue(sample["findings"], "the second vector should have findings")
        sample["findings"][0]["message"] += " (changed)"
        self.assertNotEqual(sample["findings"], self.vocab.check(sample["document"]))

    def test_the_vectors_cover_every_value_type_and_every_code(self):
        types = {spec["type"] for block in self.vocab.blocks.values()
                 for spec in block["controls"].values()}
        sampled = {self.vocab.controls(s["block"])[s["control"]]["type"]
                   for s in self.vectors["values"]}
        self.assertEqual(set(), types - sampled, "value types with no vector")
        codes = {f["code"] for d in self.vectors["documents"] for f in d["findings"]}
        self.assertEqual(set(), CODES - codes, "finding codes with no vector")

    def test_the_built_in_layout_is_valid(self):
        self.assertEqual([], self.vocab.check(self.vocab.builtin))


class Commands(unittest.TestCase):

    def setUp(self):
        self.vocab = Vocabulary.load()
        self.dir = tempfile.mkdtemp(prefix="crecs-search-test-")
        self.path = os.path.join(self.dir, "search.json")
        with open(self.path, "w", encoding="utf-8") as fh:
            json.dump(self.vocab.builtin, fh)

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def run_cli(self, *args):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = search_cli.main(["--file", self.path] + list(args))
        return code, out.getvalue(), err.getvalue()

    def doc(self):
        with open(self.path, encoding="utf-8") as fh:
            return json.load(fh)

    def settings(self, node_id):
        node = find(self.doc(), node_id)[0]
        return node["settings"] if isinstance(node["settings"], dict) else {}

    def raw(self):
        with open(self.path, "rb") as fh:
            return fh.read()

    # -- set / unset -------------------------------------------------------------

    def test_a_colour_and_its_hover(self):
        self.assertEqual(0, self.run_cli("set", "--node", PROPERTY_TYPE, "--key",
                                         "button_background_color", "--value", "#0a3d62")[0])
        self.assertEqual(0, self.run_cli("set", "--node", PROPERTY_TYPE, "--key",
                                         "button_background_color", "--hover", "--value", "#145a8d")[0])
        self.assertEqual({"button_background_color": "#0a3d62",
                          "button_background_color_hover": "#145a8d"}, self.settings(PROPERTY_TYPE))
        self.assertEqual([], self.vocab.check(self.doc()))

    def test_a_bad_value_is_refused_and_nothing_is_written(self):
        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", PROPERTY_TYPE, "--key",
                                       "button_background_color", "--value", "red")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("is not a colour", err)
        self.assertEqual(before, self.raw())

    def test_an_unknown_setting_is_refused_with_a_suggestion(self):
        code, _out, err = self.run_cli("set", "--node", PROPERTY_TYPE, "--key",
                                       "button_backgroundcolor", "--value", "#000")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("button_background_color", err)
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "map_tilt", "--value", "12")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("no map_tilt setting", err)

    def test_device_values_only_where_the_setting_is_responsive(self):
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "map_height",
                                         "--device", "mobile", "--value", "240px")[0])
        self.assertEqual({"unit": "px", "size": 240}, self.settings(MAP)["map_height_mobile"])
        code, _out, err = self.run_cli("set", "--node", PROPERTY_TYPE, "--key",
                                       "button_font_weight", "--device", "mobile", "--value", "700")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("every device", err)

    def test_shorthand_values(self):
        self.run_cli("set", "--node", FILTERS, "--key", "_width", "--value", "300px")
        self.run_cli("set", "--node", FILTERS, "--key", "panel_padding", "--value", "8px 16px")
        self.run_cli("set", "--node", FILTERS, "--key", "panel_box_shadow",
                     "--value", "0 2px 8px 0 rgba(0,0,0,0.2)")
        self.run_cli("set", "--node", FILTERS, "--key", "direction", "--value", "column")
        settings = self.settings(FILTERS)
        self.assertEqual({"unit": "px", "size": 300}, settings["_width"])
        self.assertEqual({"unit": "px", "top": 8, "right": 16, "bottom": 8, "left": 16,
                          "isLinked": False}, settings["panel_padding"])
        self.assertEqual({"horizontal": 0, "vertical": 2, "blur": 8, "spread": 0,
                          "color": "rgba(0,0,0,0.2)"}, settings["panel_box_shadow"])
        self.assertEqual([], self.vocab.check(self.doc()))

    def test_switch_no_removes_the_setting(self):
        self.run_cli("set", "--node", LISTINGS, "--key", "_grow", "--value", "yes")
        self.assertEqual("yes", self.settings(LISTINGS)["_grow"])
        self.run_cli("set", "--node", LISTINGS, "--key", "_grow", "--value", "no")
        self.assertNotIn("_grow", self.settings(LISTINGS))

    def test_unset_leaves_an_empty_list_as_the_plugin_stores_it(self):
        self.run_cli("set", "--node", MAP, "--key", "map_height", "--value", "300px")
        self.run_cli("unset", "--node", MAP, "--key", "map_height")
        node = find(self.doc(), MAP)[0]
        self.assertEqual([], node["settings"])
        # And so the skill's hash of the untouched layout is the one the site reports.
        self.assertEqual(canonical_hash(normalise(copy.deepcopy(self.vocab.builtin))["content"]),
                         canonical_hash(self.doc()["content"]))

    # -- texts -------------------------------------------------------------------

    def test_a_text_is_set_and_put_back(self):
        self.assertEqual(0, self.run_cli("text", "--node", PROPERTY_TYPE, "--slot", "button",
                                         "--value", "Tipo de imóvel")[0])
        self.assertEqual("Tipo de imóvel", self.settings(PROPERTY_TYPE)["text_button"])
        self.run_cli("text", "--node", PROPERTY_TYPE, "--slot", "button", "--reset")
        self.assertNotIn("text_button", self.settings(PROPERTY_TYPE))
        code, _out, err = self.run_cli("text", "--node", PROPERTY_TYPE, "--slot", "title",
                                       "--value", "x")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("its texts: button", err)

    def test_a_text_on_two_lines_is_refused(self):
        code, _out, err = self.run_cli("text", "--node", CLEAR, "--slot", "label",
                                       "--value", "Clear\nall")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("one line", err)

    # -- structure ---------------------------------------------------------------

    def test_the_sort_cannot_go_into_the_filters(self):
        before = self.raw()
        code, _out, err = self.run_cli("move", "--node", SORT, "--into", FILTERS)
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn("E-SL-NOT-WITHIN", err)
        self.assertEqual(before, self.raw())

    def test_a_filter_cannot_leave_the_filters(self):
        code, _out, err = self.run_cli("move", "--node", RATE, "--before", SORT)
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn("E-SL-WITHIN", err)

    def test_moving_within_the_filters(self):
        self.assertEqual(0, self.run_cli("move", "--node", CLEAR, "--into", FILTERS,
                                         "--position", "0")[0])
        filters = find(self.doc(), FILTERS)[0]
        self.assertEqual(CLEAR, filters["elements"][0]["id"])

    def test_a_block_cannot_go_inside_itself(self):
        code, _out, err = self.run_cli("move", "--node", WRAPPER, "--into", FILTERS)
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("inside itself", err)

    def test_filters_beside_the_results_in_a_box_and_back(self):
        code, out, _err = self.run_cli("--json", "add-box", "--wrap", FILTERS + "," + LISTINGS,
                                       "--direction", "row")
        self.assertEqual(0, code)
        result = json.loads(out)
        self.assertEqual([FILTERS, LISTINGS], result["holds"])
        self.assertIn("direction", result.get("hint", ""), "the main area's layout was not mentioned")
        box = find(self.doc(), result["node"])[0]
        self.assertEqual("crecs_search_box", box["widgetType"])
        self.assertEqual([], self.vocab.check(self.doc()))

        self.assertEqual(0, self.run_cli("remove-box", "--node", result["node"])[0])
        self.assertEqual(self.vocab.builtin["content"], self.doc()["content"])

    def test_only_a_box_can_be_removed(self):
        code, _out, err = self.run_cli("remove-box", "--node", MAP)
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("not a box", err)

    def test_a_box_cannot_hold_what_it_sits_in(self):
        code, _out, err = self.run_cli("add-box", "--into", FILTERS, "--wrap", FILTERS)
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("sits in", err)

    def test_hiding_only_where_the_page_allows_it(self):
        code, out, _err = self.run_cli("--json", "add-box", "--into", WRAPPER)
        box = json.loads(out)["node"]
        self.assertEqual(0, self.run_cli("hide", "--node", box, "--device", "mobile")[0])
        self.assertEqual("yes", self.settings(box)["_hide_mobile"])
        # The map hides where it has no button of its own, and only there.
        self.assertEqual(0, self.run_cli("hide", "--node", MAP, "--device", "mobile")[0])
        code, _out, err = self.run_cli("hide", "--node", MAP, "--device", "desktop")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("_hide_desktop", err)
        # The results never hide: the page always keeps a view.
        code, _out, err = self.run_cli("hide", "--node", RESULTS, "--device", "mobile")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("_hide_mobile", err)

    # -- what the page starts with -------------------------------------------------

    def test_a_shorter_list_that_starts_checked(self):
        self.assertEqual(0, self.run_cli("set", "--node", PROPERTY_TYPE, "--key", "offer",
                                         "--value", "Office, Industrial, Retail")[0])
        self.assertEqual(0, self.run_cli("set", "--node", PROPERTY_TYPE, "--key", "start_checked",
                                         "--value", '["office"]')[0])
        self.assertEqual(["Office", "Industrial", "Retail"], self.settings(PROPERTY_TYPE)["offer"])
        self.assertEqual(["office"], self.settings(PROPERTY_TYPE)["start_checked"])
        self.assertEqual([], self.vocab.check(self.doc()))
        # An empty list is no list: the setting goes, and the site's whole list is back.
        self.assertEqual(0, self.run_cli("set", "--node", PROPERTY_TYPE, "--key", "start_checked",
                                         "--value", "[]")[0])
        self.assertNotIn("start_checked", self.settings(PROPERTY_TYPE))

    def test_a_start_the_list_does_not_offer_is_refused(self):
        self.run_cli("set", "--node", PROPERTY_TYPE, "--key", "offer", "--value", "Office")
        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", PROPERTY_TYPE, "--key", "start_checked",
                                       "--value", "Retail")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('names "Retail", which "offer" does not list', err)
        self.assertEqual(before, self.raw())

    def test_amounts_as_people_write_them(self):
        self.assertEqual(0, self.run_cli("set", "--node", SIZE, "--key", "start_min",
                                         "--value", "5,000")[0])
        self.assertEqual(5000, self.settings(SIZE)["start_min"])
        self.assertEqual(0, self.run_cli("set", "--node", RATE, "--key", "start_max",
                                         "--value", "$12.50")[0])
        self.assertEqual(12.5, self.settings(RATE)["start_max"])
        code, _out, err = self.run_cli("set", "--node", SIZE, "--key", "start_max", "--value", "1000")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('"start_min" is larger than "start_max"', err)
        code, _out, _err = self.run_cli("set", "--node", SIZE, "--key", "start_max", "--value", "lots")
        self.assertEqual(search_cli.EXIT_USAGE, code)

    def test_a_starting_value_nobody_could_remove_is_refused(self):
        self.assertEqual(0, self.run_cli("set", "--node", KEYWORD, "--key", "start_text",
                                         "--value", "Warehouse")[0])
        self.assertEqual(0, self.run_cli("hide", "--node", KEYWORD, "--device", "mobile")[0])
        before = self.raw()
        code, _out, err = self.run_cli("hide", "--node", CLEAR, "--device", "mobile")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn("E-SL-STUCK", err)
        self.assertEqual(before, self.raw())
        # Clear may hide where the starting value can be seen.
        self.assertEqual(0, self.run_cli("hide", "--node", CLEAR, "--device", "tablet")[0])

    def test_a_hidden_choice_and_the_unit_the_size_starts_in(self):
        code, _out, err = self.run_cli("set", "--node", SIZE, "--key", "square_feet_option_hide",
                                       "--value", "yes")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn("starts in square_feet", err)
        self.assertEqual(0, self.run_cli("set", "--node", SIZE, "--key", "start_unit",
                                         "--value", "acres")[0])
        self.assertEqual(0, self.run_cli("set", "--node", SIZE, "--key", "square_feet_option_hide",
                                         "--value", "yes")[0])
        self.assertEqual([], self.vocab.check(self.doc()))

    def test_show_names_what_a_block_starts_with(self):
        code, out, _err = self.run_cli("show", "--node", SIZE)
        self.assertEqual(0, code)
        self.assertIn("options: start_unit, start_min, start_max", out)

    # -- the cards and the map popup ---------------------------------------------

    def test_the_cards_lines_and_the_popups_parts_in_plain_words(self):
        self.assertEqual(0, self.run_cli("set", "--node", RESULTS, "--key", "card_fields",
                                         "--value", "name, rates, buttons")[0])
        self.assertEqual(["name", "rates", "buttons"], self.settings(RESULTS)["card_fields"])
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "popup_fields",
                                         "--value", "photo, name, view_button")[0])
        self.assertEqual(["photo", "name", "view_button"], self.settings(MAP)["popup_fields"])
        code, _out, err = self.run_cli("set", "--node", RESULTS, "--key", "card_fields",
                                       "--value", "name, gallery")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn('has no part "gallery"', err)
        self.assertEqual([], self.vocab.check(self.doc()))

    # -- the map itself ----------------------------------------------------------

    def test_the_map_opens_where_and_how_the_layout_says(self):
        for key, value in (("map_zoom", "12"), ("map_center", "38.627, -90.199"),
                           ("map_style", "dark"), ("map_water_color", "#0a3d62"),
                           ("map_street_view_control", "hidden")):
            self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", key, "--value", value)[0], key)
        self.assertEqual({"map_zoom": 12, "map_center_lat": 38.627, "map_center_lng": -90.199,
                          "map_style": "dark", "map_water_color": "#0a3d62",
                          "map_street_view_control": "hidden"}, self.settings(MAP))
        self.assertEqual([], self.vocab.check(self.doc()))
        # The centre is set and taken away as one.
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "map_center",
                                         "--value", '{"lat": 40.7, "lng": -74}')[0])
        self.assertEqual((40.7, -74), (self.settings(MAP)["map_center_lat"], self.settings(MAP)["map_center_lng"]))
        self.assertEqual(0, self.run_cli("unset", "--node", MAP, "--key", "map_center")[0])
        self.assertNotIn("map_center_lat", self.settings(MAP))
        self.assertNotIn("map_center_lng", self.settings(MAP))
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "map_center", "--value", "38.627")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("give both", err)
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "map_center", "--value", "95, 10")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("from -90 to 90", err)

    def test_half_a_centre_or_a_colour_the_map_cannot_read_is_refused(self):
        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "map_center_lat", "--value", "38.627")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('go together', err)
        self.assertEqual(before, self.raw())
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "map_water_color", "--value", "blue")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("#rrggbb", err)
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "map_center_lng", "--value", "90,199")
        self.assertEqual(search_cli.EXIT_USAGE, code)

    # -- the pins and the groups of pins -------------------------------------------

    def test_a_drawn_pin_or_an_image_and_the_order_to_change_from_one_to_the_other(self):
        for key, value in (("pin_shape", "building"), ("pin_color", "#0a3d62"), ("pin_size", "40"),
                           ("cluster_color", "#0a3d62"), ("cluster_numbers", "hidden")):
            self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", key, "--value", value)[0], key)
        self.assertEqual({"pin_shape": "building", "pin_color": "#0a3d62", "pin_size": 40,
                          "cluster_color": "#0a3d62", "cluster_numbers": "hidden"}, self.settings(MAP))
        self.assertEqual([], self.vocab.check(self.doc()))

        # One kind of pin: the image waits until the drawn pin and its colour are gone.
        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "pin_image", "--value", "6543")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn("two kinds of pin", err)
        code, _out, err = self.run_cli("unset", "--node", MAP, "--key", "pin_shape")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('"pin_color" colours a pin the plugin draws', err)
        self.assertEqual(before, self.raw())
        for key in ("pin_color", "pin_shape"):
            self.assertEqual(0, self.run_cli("unset", "--node", MAP, "--key", key)[0], key)
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "pin_image", "--value", "6543")[0])
        self.assertEqual(6543, self.settings(MAP)["pin_image"])

        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "pin_image", "--value", "our logo")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("crecs_preview.py media", err)
        rows = {row["name"]: row for row in search_cli.control_rows(self.vocab, self.doc(), MAP, "pin_")}
        self.assertEqual("an image's number (crecs_preview.py media)", rows["pin_image"]["allowed"])
        self.assertEqual("one of pin|circle|square|building", rows["pin_shape"]["allowed"])

    def test_pins_by_property_type_and_the_page_pins_put_right_only_when_asked(self):
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "type_pins", "--value",
                                         "Retail: building #00aa33 #fff; Office")[0])
        self.assertEqual([{"type": "Retail", "shape": "building", "color": "#00aa33", "accent": "#fff"},
                          {"type": "Office"}], self.settings(MAP)["type_pins"])
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "type_pins", "--value",
                                         '[{"type": "Medical Office", "color": "#0a3d62"}]')[0])
        self.assertEqual([{"type": "Medical Office", "color": "#0a3d62"}], self.settings(MAP)["type_pins"])

        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "type_pins", "--value", "Retail; retail ")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn('names the type "retail" twice', err)
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "type_pins", "--value", "Retail: star")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("neither a shape", err)
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "type_pins", "--value", "Retail: #111 #222 #333")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("at most two colours", err)
        self.assertEqual(before, self.raw())

        for key, value in (("cre_cloud_type_pins", "replaced"), ("pin_position", "point"),
                           ("cluster_position", "centred")):
            self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", key, "--value", value)[0], key)
        self.assertEqual([], self.vocab.check(self.doc()))
        self.assertEqual(0, self.run_cli("unset", "--node", MAP, "--key", "type_pins")[0])
        self.assertNotIn("type_pins", self.settings(MAP))

    # -- the mouse over cards and pins ------------------------------------------------

    def test_the_mouse_over_effects_and_the_colour_only_for_an_outline(self):
        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", RESULTS, "--key", "card_highlight_color",
                                       "--value", "#0a3d62")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('"card_highlight_color" colours a card\'s outline', err)
        self.assertEqual(before, self.raw())
        for node, key, value in ((RESULTS, "card_hover", "lift"), (RESULTS, "card_on_pin_hover", "outline"),
                                 (RESULTS, "card_highlight_color", "#0a3d62"),
                                 (MAP, "pin_on_card_hover", "grow"), (MAP, "pin_hover_popup", "yes")):
            self.assertEqual(0, self.run_cli("set", "--node", node, "--key", key, "--value", value)[0], key)
        self.assertEqual({"card_hover": "lift", "card_on_pin_hover": "outline", "card_highlight_color": "#0a3d62"},
                         self.settings(RESULTS))
        self.assertEqual({"pin_on_card_hover": "grow", "pin_hover_popup": "yes"}, self.settings(MAP))
        self.assertEqual([], self.vocab.check(self.doc()))
        # "no" for a switch takes the setting away: the popup opens on a click only again.
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "pin_hover_popup", "--value", "no")[0])
        self.assertNotIn("pin_hover_popup", self.settings(MAP))

    # -- the Stage 7 rehearsal ---------------------------------------------------------

    def test_a_shorter_lists_filter_cannot_be_hidden(self):
        self.assertEqual(0, self.run_cli("set", "--node", PROPERTY_TYPE, "--key", "offer", "--value", "Office")[0])
        before = self.raw()
        code, _out, err = self.run_cli("hide", "--node", PROPERTY_TYPE, "--device", "mobile")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('"offer" holds every search to the names it lists', err)
        self.assertIn("it is hidden on mobile", err)
        self.assertEqual(before, self.raw())

    def test_a_layout_already_refused_is_mended_a_step_at_a_time(self):
        # A layout from before a rule: a shorter list's filter hidden everywhere.
        doc = copy.deepcopy(self.vocab.builtin)
        node = find(doc, PROPERTY_TYPE)[0]
        node["settings"] = {"offer": ["Office"], "_hide_desktop": "yes", "_hide_tablet": "yes",
                            "_hide_mobile": "yes"}
        with open(self.path, "w", encoding="utf-8") as fh:
            json.dump(doc, fh)

        for device, left in (("desktop", "tablet, mobile"), ("tablet", "mobile")):
            code, out, err = self.run_cli("unhide", "--node", PROPERTY_TYPE, "--device", device)
            self.assertEqual(0, code, device)
            self.assertIn("written, but the plugin would still refuse the layout", err)
            self.assertIn("it is hidden on %s" % left, err)
            self.assertNotIn("_hide_" + device, self.settings(PROPERTY_TYPE))

        # A change that makes it worse is still refused, mid-repair or not.
        before = self.raw()
        code, _out, err = self.run_cli("hide", "--node", PROPERTY_TYPE, "--device", "tablet")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertEqual(before, self.raw())

        code, _out, err = self.run_cli("unhide", "--node", PROPERTY_TYPE, "--device", "mobile")
        self.assertEqual(0, code)
        self.assertNotIn("would still refuse", err)
        self.assertEqual([], self.vocab.check(self.doc()))

    def test_nothing_about_the_groups_while_pins_do_not_group(self):
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "cluster_size", "--value", "40")[0])
        before = self.raw()
        code, _out, err = self.run_cli("set", "--node", MAP, "--key", "cluster", "--value", "off")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn('"cluster_size" does nothing while "cluster" is "off"', err)
        self.assertEqual(before, self.raw())
        self.assertEqual(0, self.run_cli("unset", "--node", MAP, "--key", "cluster_size")[0])
        self.assertEqual(0, self.run_cli("set", "--node", MAP, "--key", "cluster", "--value", "off")[0])
        self.assertEqual({"cluster": "off"}, self.settings(MAP))

    def test_columns_are_set_per_device(self):
        self.assertEqual(0, self.run_cli("set", "--node", RESULTS, "--key", "grid_columns",
                                         "--value", "3")[0])
        self.assertEqual(0, self.run_cli("set", "--node", RESULTS, "--key", "grid_columns",
                                         "--device", "mobile", "--value", "1")[0])
        self.assertEqual({"grid_columns": 3, "grid_columns_mobile": 1}, self.settings(RESULTS))
        code, _out, err = self.run_cli("set", "--node", RESULTS, "--key", "grid_columns",
                                       "--device", "mobile", "--value", "3")
        self.assertEqual(search_cli.EXIT_USAGE, code)
        self.assertIn("from 1 to 2", err)

    # -- the file ----------------------------------------------------------------

    def test_the_file_can_be_named_before_or_after_the_command(self):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = search_cli.main(["show", "--file", self.path])
        self.assertEqual(0, code)
        self.assertIn("Property type filter", out.getvalue())

    def test_a_property_template_is_refused(self):
        with open(self.path, "w", encoding="utf-8") as fh:
            json.dump({"version": "0.4", "type": "page", "content": []}, fh)
        code, _out, err = self.run_cli("show")
        self.assertEqual(search_cli.EXIT_FILE, code)
        self.assertIn("crecs_template.py", err)

    def test_an_export_payload_is_read_as_its_document(self):
        with open(self.path, "w", encoding="utf-8") as fh:
            json.dump({"document": self.vocab.builtin, "manifest": {"kind": "search"}}, fh)
        self.assertEqual(0, self.run_cli("validate")[0])

    def test_validate_reports_what_the_plugin_would_refuse(self):
        doc = copy.deepcopy(self.vocab.builtin)
        wrapper = find(doc, WRAPPER)[0]
        wrapper["elements"] = [n for n in wrapper["elements"] if n["id"] != MAP]
        with open(self.path, "w", encoding="utf-8") as fh:
            json.dump(doc, fh)
        code, out, _err = self.run_cli("validate")
        self.assertEqual(search_cli.EXIT_REFUSED, code)
        self.assertIn("E-SL-REQUIRED", out)
        self.assertTrue(blocking(self.vocab.check(doc)))


class PreviewOptions(unittest.TestCase):
    """crecs_preview.py options: the site's own names, in full, and never the token."""

    def test_the_names_come_in_full_and_the_token_never_shows(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                seen["path"] = self.path
                seen["auth"] = self.headers.get("Authorization")
                body = json.dumps({"property_types": ["Industrial", "Office"],
                                   "brokers": ["Jane Doe, SIOR"]}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):  # keep the test output readable
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        folder = tempfile.mkdtemp(prefix="crecs-options-test-")
        try:
            session = os.path.join(folder, "session.json")
            with open(session, "w", encoding="utf-8") as fh:
                json.dump({"id": "ps_test", "token": "token-secret-123",
                           "base": "http://127.0.0.1:%d" % server.server_port}, fh)
            out, err = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                code = crecs_preview.main(["options", "--session-file", session])
        finally:
            server.shutdown()
            server.server_close()
            shutil.rmtree(folder, ignore_errors=True)
        self.assertEqual(0, code)
        self.assertEqual("/wp-json/crecs/preview/v1/sessions/ps_test/search-options", seen["path"])
        self.assertEqual("Bearer token-secret-123", seen["auth"])
        self.assertEqual("property types (2):\n  Industrial\n  Office\nbrokers (1):\n  Jane Doe, SIOR\n",
                         out.getvalue())
        self.assertNotIn("token-secret-123", out.getvalue() + err.getvalue())


class PreviewMedia(unittest.TestCase):
    """crecs_preview.py media: the site's images by number, and never the token."""

    def test_the_images_come_numbered_newest_first_and_the_token_never_shows(self):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                seen["path"] = self.path
                seen["auth"] = self.headers.get("Authorization")
                body = json.dumps({"images": [
                    {"id": 6543, "title": "Our logo", "file": "logo.png", "url": "https://example.test/logo.png",
                     "width": 300, "height": 120, "uploaded": "2026-10-06T12:00:00+00:00"},
                    {"id": 12, "title": "", "file": "pin.svg", "url": "https://example.test/pin.svg",
                     "width": 0, "height": 0, "uploaded": "2026-01-02T00:00:00+00:00"},
                ]}).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):  # keep the test output readable
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        folder = tempfile.mkdtemp(prefix="crecs-media-test-")
        try:
            session = os.path.join(folder, "session.json")
            with open(session, "w", encoding="utf-8") as fh:
                json.dump({"id": "ps_test", "token": "token-secret-123",
                           "base": "http://127.0.0.1:%d" % server.server_port}, fh)
            out, err = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                code = crecs_preview.main(["media", "--search", "our logo", "--session-file", session])
        finally:
            server.shutdown()
            server.server_close()
            shutil.rmtree(folder, ignore_errors=True)
        self.assertEqual(0, code)
        self.assertEqual("/wp-json/crecs/preview/v1/sessions/ps_test/media?search=our+logo", seen["path"])
        self.assertEqual("Bearer token-secret-123", seen["auth"])
        self.assertEqual("images (2), newest first:\n"
                         "     6543  Our logo  [logo.png, 300x120, uploaded 2026-10-06]\n"
                         "       12  (no title)  [pin.svg, size unknown, uploaded 2026-01-02]\n",
                         out.getvalue())
        self.assertNotIn("token-secret-123", out.getvalue() + err.getvalue())


class PreviewPublished(unittest.TestCase):
    """crecs_preview.py published: whether the layout on display is live, said plainly,
    so the assistant checks after the person presses Publish instead of assuming."""

    def run_against(self, state, argv):
        seen = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                seen["path"] = self.path
                body = json.dumps(state).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):  # keep the test output readable
                pass

        server = HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        folder = tempfile.mkdtemp(prefix="crecs-published-test-")
        try:
            session = os.path.join(folder, "session.json")
            with open(session, "w", encoding="utf-8") as fh:
                json.dump({"id": "ps_test", "token": "token-secret-123",
                           "base": "http://127.0.0.1:%d" % server.server_port}, fh)
            out, err = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                code = crecs_preview.main(argv + ["--session-file", session])
        finally:
            server.shutdown()
            server.server_close()
            shutil.rmtree(folder, ignore_errors=True)
        self.assertEqual("/wp-json/crecs/preview/v1/sessions/ps_test/state", seen["path"])
        self.assertNotIn("token-secret-123", out.getvalue() + err.getvalue())
        return code, out.getvalue()

    def search_state(self, live_hash):
        return {"kind": "search", "head": 4, "ready_revision": 4, "ready_hash": "a" * 64,
                "last_state": "ready", "live_hash": live_hash}

    def test_live_when_the_live_page_has_the_ready_revisions_hash(self):
        code, out = self.run_against(self.search_state("a" * 64), ["published"])
        self.assertEqual(0, code)
        self.assertEqual("yes: the live search page shows revision 4, the layout on display in "
                         "the preview.\n", out)

    def test_not_live_otherwise(self):
        code, out = self.run_against(self.search_state("b" * 64), ["published"])
        self.assertEqual(0, code)
        self.assertTrue(out.startswith("no: the live search page does not show revision 4"), out)

    def test_json_answers_with_a_boolean(self):
        code, out = self.run_against(self.search_state("b" * 64), ["published", "--json"])
        self.assertEqual(0, code)
        self.assertIs(False, json.loads(out)["live"])

    def test_a_property_session_is_not_published(self):
        code, out = self.run_against({"kind": "property", "head": 1, "ready_revision": 1,
                                      "ready_hash": "a" * 64}, ["published"])
        self.assertEqual(0, code)
        self.assertIn("not a search page preview", out)

    def test_state_says_live_for_a_search_session(self):
        code, out = self.run_against(self.search_state("a" * 64), ["state"])
        self.assertEqual(0, code)
        self.assertIn("\nlive                   yes\n", "\n" + out)


class PublishingInstructions(unittest.TestCase):
    """What SKILL.md tells the person about Publish. Testing 1.3.10, an assistant told a
    client to open the preview in their usual browser and confirm with OK: the old
    flow, which plugin 2.8.10 replaced with a bar in the page that the Claude app's
    browser shows. OK belongs only to sites still on an older plugin."""

    def setUp(self):
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "SKILL.md")
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        start = text.index("### Going live")
        self.section = text[start:text.index("\n## ", start)]

    def test_the_question_is_the_bar_in_the_page(self):
        self.assertIn("**Yes, publish**", self.section)
        self.assertIn("Claude app's browser too", self.section)
        self.assertIn("no **OK**", self.section)
        self.assertIn("never tell them to open the preview in another browser", self.section)

    def test_ok_is_only_for_an_older_plugin(self):
        for paragraph in self.section.split("\n\n"):
            if "OK**" in paragraph and "no **OK**" not in paragraph:
                self.assertIn("older than 2.8.10", paragraph, paragraph)

    def test_it_is_checked_after_publish(self):
        self.assertIn("crecs_preview.py published", self.section)


class Reference(unittest.TestCase):

    def test_the_reference_is_the_plugins(self):
        with open(REFERENCE, encoding="utf-8") as fh:
            data = json.load(fh)
        self.assertIn("Generated by the CRE Cloud Solutions plugin", data["_comment"])
        self.assertEqual({"type": "crecs-search-layout", "version": 1}, data["document"])

    def test_every_block_in_the_built_in_layout_is_known(self):
        vocab = Vocabulary.load()
        for node, *_ in search_cli.walk(vocab.builtin):
            self.assertIn(node["widgetType"], vocab.blocks)


if __name__ == "__main__":
    unittest.main()
